package com.example.news24.service;

import com.example.news24.entity.Article;

import java.util.List;

public interface ArticleService {
    Article saveArticle(Article article);
    List<Article> getAllArticles();

    Article findById(Long id);
    List<Article> findLastThreeArticles();
}
