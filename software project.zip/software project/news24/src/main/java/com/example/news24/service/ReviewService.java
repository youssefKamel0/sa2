package com.example.news24.service;

import com.example.news24.entity.Review;
import java.util.List;

public interface ReviewService {

    List<Review> findByArticleId(Long articleId);

    boolean hasUserReviewed(Long userId, Long articleId);

    List<Review> getReviewsByArticleId(Long articleId);

    void addReview(Review review);
}
