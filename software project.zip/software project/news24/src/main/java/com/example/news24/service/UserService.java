package com.example.news24.service;

import com.example.news24.entity.User;

import java.util.List;

public interface UserService {
    User saveUser(User user);
    User authenticateUser(String email, String password);
    User getUserByEmail(String email);
    public boolean isEmailExists(String email);

}
