package com.example.news24.repo;

import com.example.news24.entity.Publisher;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PublisherRepo extends JpaRepository<Publisher, Long> {
    Publisher findByEmail(String email);
}
