package com.example.news24.service.impl;

import com.example.news24.entity.Publisher;
import com.example.news24.entity.User;
import com.example.news24.repo.PublisherRepo;
import com.example.news24.service.PublisherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class publisherServiceimpl implements PublisherService {

    @Autowired
    private PublisherRepo publisherrepo;

    public publisherServiceimpl(PublisherRepo publisherrepo) {
        this.publisherrepo = publisherrepo;
    }

    @Override
    public Publisher savePublisher(Publisher publisher) {
        return publisherrepo.save(publisher);
    }

    @Override
    public Publisher authenticateUser(String email, String password) {
        Publisher publisher = publisherrepo.findByEmail(email);
        if (publisher != null && BCrypt.checkpw(password, publisher.getPassword())) {
            return publisher;
        }
        return null; // Authentication failed
    }

    @Override
    public Publisher getUserByEmail(String email) {
        return publisherrepo.findByEmail(email);
    }

    @Override
    public boolean isEmailExists(String email) {
        Optional<Publisher> existingPublisher = Optional.ofNullable(publisherrepo.findByEmail(email));
        return existingPublisher.isPresent();
    }

}
