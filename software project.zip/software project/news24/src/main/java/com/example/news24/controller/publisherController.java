package com.example.news24.controller;

import com.example.news24.entity.Publisher;
import com.example.news24.service.PublisherService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class publisherController {

    private final PublisherService publisherService;
    private final PublisherValidator publisherValidator;

    @Autowired
    public publisherController(PublisherService publisherService, PublisherValidator publisherValidator) {
        this.publisherService = publisherService;
        this.publisherValidator = publisherValidator;
    }

    @GetMapping("/register-publisher")
    public String showRegistrationForm(Model model, HttpSession session) {
        if (session.getAttribute("user") != null || session.getAttribute("publisher") != null) {
            return "redirect:/";
        }else {
            model.addAttribute("publisher", new Publisher());
            return "register-publisher";
        }

    }

    @PostMapping("/register-publisher")
    public String processRegistrationForm(@ModelAttribute("publisher") Publisher publisher, BindingResult result, RedirectAttributes redirectAttributes) {
        publisherValidator.validate(publisher, result);
        if (result.hasErrors()) {
            return "register-publisher";
        }

        if (publisherService.isEmailExists(publisher.getEmail())) {
            result.rejectValue("email", "error.publisher", "Email already exists");
            return "register-publisher"; // Return to registration form with email exists error
        }

        String hashedPassword = BCrypt.hashpw(publisher.getPassword(), BCrypt.gensalt());
        publisher.setPassword(hashedPassword);

        // Save user to the database
        publisherService.savePublisher(publisher);

        redirectAttributes.addFlashAttribute("message", "Registration successful! Please login.");

        return "redirect:/login-publisher";
    }

    @GetMapping("/login-publisher")
    public String showLoginPage(HttpSession session) {
        if (session.getAttribute("user") != null || session.getAttribute("publisher") != null) {
            return "redirect:/";
        }
        return "login-publisher";
    }

    @PostMapping("/login-publisher")
    public String processLoginForm(@RequestParam String email, @RequestParam String password, RedirectAttributes redirectAttributes, HttpSession session) {

        // Validate email and password (optional)
        if (email.isEmpty() || password.isEmpty()) {
            redirectAttributes.addFlashAttribute("error", "Please provide email and password");
            return "redirect:/login-publisher";
        }

        // Authenticate user
        Publisher authenticatedPublisher = publisherService.authenticateUser(email, password);

        if (authenticatedPublisher != null) {
            // Set user object in session upon successful authentication
            session.setAttribute("publisher", authenticatedPublisher);
            return "redirect:/";
        } else {
            // If authentication fails, redirect to login page with error message
            redirectAttributes.addFlashAttribute("error", "Invalid email or password");
            return "redirect:/login-publisher";
        }
    }

}
