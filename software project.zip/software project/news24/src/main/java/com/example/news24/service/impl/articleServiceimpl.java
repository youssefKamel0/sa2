package com.example.news24.service.impl;

import com.example.news24.entity.Article;
import com.example.news24.repo.ArticleRepo;
import com.example.news24.service.ArticleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class articleServiceimpl implements ArticleService {
    @Autowired
    private ArticleRepo articleRepo;

    public articleServiceimpl(ArticleRepo articlerepo) {
        this.articleRepo = articlerepo;
    }

    @Override
    public List<Article> getAllArticles() {
        return articleRepo.findAll();
    }

    @Override
    public Article saveArticle(Article article) {
        return articleRepo.save(article);
    }


    @Override
    public List<Article> findLastThreeArticles() {
        // Retrieve the last three articles based on their publication date
        return articleRepo.findThreeRandomArticles();
    }


    @Override
    public Article findById(Long id) {
        return articleRepo.findById(id).orElse(null);
    }

}
