package com.example.news24.repo;

import com.example.news24.entity.Review;
import org.springframework.stereotype.Repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public interface ReviewRepo extends JpaRepository<Review, Long> {

    List<Review> findByArticleId(Long articleId);

    boolean existsByUserIdAndArticleId(Long userId, Long articleId);

}
