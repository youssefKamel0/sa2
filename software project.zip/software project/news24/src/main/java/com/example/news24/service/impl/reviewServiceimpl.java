package com.example.news24.service.impl;

import com.example.news24.entity.Review;
import com.example.news24.repo.ReviewRepo;
import com.example.news24.service.ReviewService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class reviewServiceimpl implements ReviewService {

    @Autowired
    private ReviewRepo reviewRepository;

    @Override
    public List<Review> findByArticleId(Long articleId) {
        return reviewRepository.findByArticleId(articleId);
    }

    @Override
    public boolean hasUserReviewed(Long userId, Long articleId) {
        return reviewRepository.existsByUserIdAndArticleId(userId, articleId);
    }

    @Override
    public void addReview(Review review) {
        reviewRepository.save(review);
    }

    @Override
    public List<Review> getReviewsByArticleId(Long articleId) {
        return reviewRepository.findByArticleId(articleId);
    }
}
