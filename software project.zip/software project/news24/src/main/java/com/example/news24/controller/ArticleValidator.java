package com.example.news24.controller;

import com.example.news24.entity.Article;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

@Component
public class ArticleValidator implements Validator {
    @Override
    public boolean supports(Class<?> clazz) {
        return Article.class.equals(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        Article article = (Article) target;

        // Validate title
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "title", "field.required", "Title is required");

//        // Validate description
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "description", "field.required", "Description is required");
        if (article.getDescription() != null && article.getDescription().length() < 10) {
            errors.rejectValue("description", "description.minlength", "Description must be at least 10 characters");
        }
//        // Validate image
//        if (article.getImage() == null || article.getImage().isEmpty()) {
//            errors.rejectValue("image", "field.required", "Image is required");
//        }
    }
}
