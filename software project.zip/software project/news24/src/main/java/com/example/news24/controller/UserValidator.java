package com.example.news24.controller;

import com.example.news24.entity.User;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
@Component
public class UserValidator implements Validator {

    @Override
    public boolean supports(Class<?> clazz) {
        return User.class.equals(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {
        User user = (User) target;

        // Validate first name
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "first_name", "field.required", "First name is required");

        // Validate last name
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "last_name", "field.required", "Last name is required");

        // Validate email
        if (!org.apache.commons.validator.routines.EmailValidator.getInstance().isValid(user.getEmail())) {
            errors.rejectValue("email", "email.invalid", "Invalid email format");
        }

        // Validate password
        if (user.getPassword() == null || user.getPassword().length() < 6) {
            errors.rejectValue("password", "password.invalid", "Password must be at least 6 characters");
        }
    }
}