package com.example.news24.controller;

import com.example.news24.entity.Article;
import com.example.news24.service.ArticleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class homeController {

    private final ArticleService articleService;

    @Autowired
    public homeController(ArticleService articleService) {
        this.articleService = articleService;
    }

    @GetMapping("/")
    public String index(Model model) {
        List<Article> articles = articleService.getAllArticles(); // Retrieve articles from the service
        model.addAttribute("articles", articles); // Add articles to the model
        return "index";
    }
}
