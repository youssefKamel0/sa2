package com.example.news24.repo;

import com.example.news24.entity.Article;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface ArticleRepo extends JpaRepository<Article, Long> {
    @Query(value = "SELECT * FROM articles LIMIT 3", nativeQuery = true)
    List<Article> findThreeRandomArticles();
}
