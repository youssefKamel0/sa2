package com.example.news24.controller;

import com.example.news24.entity.User;
import com.example.news24.service.UserService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.validation.Valid;
import java.util.List;

@Controller
public class UserController {

    private final UserService userService;
    private final UserValidator userValidator;

    @Autowired
    public UserController(UserService userService, UserValidator userValidator) {
        this.userService = userService;
        this.userValidator = userValidator;
    }

    @GetMapping("/register")
    public String showRegistrationForm(Model model, HttpSession session) {
        if (session.getAttribute("user") != null || session.getAttribute("publisher") != null) {
            return "redirect:/";
        }else {
            model.addAttribute("user", new User());
            return "register";
        }

    }

    @PostMapping("/register")
    public String processRegistrationForm(@ModelAttribute("user") User user, BindingResult result,RedirectAttributes redirectAttributes) {
        userValidator.validate(user, result);
        if (result.hasErrors()) {
            return "register";
        }

        if (userService.isEmailExists(user.getEmail())) {
            result.rejectValue("email", "error.publisher", "Email already exists");
            return "register"; // Return to registration form with email exists error
        }

        String hashedPassword = BCrypt.hashpw(user.getPassword(), BCrypt.gensalt());
        user.setPassword(hashedPassword);

        // Save user to the database
        userService.saveUser(user);

        redirectAttributes.addFlashAttribute("message", "Registration successful! Please login.");

        return "redirect:/login";
    }

    @GetMapping("/login")
    public String showLoginPage(HttpSession session) {
        if (session.getAttribute("user") != null || session.getAttribute("publisher") != null) {
            return "redirect:/";
        }
        return "login";
    }

    @PostMapping("/login")
    public String processLoginForm(@RequestParam String email, @RequestParam String password, RedirectAttributes redirectAttributes, HttpSession session) {

        // Validate email and password (optional)
        if (email.isEmpty() || password.isEmpty()) {
            redirectAttributes.addFlashAttribute("error", "Please provide email and password");
            return "redirect:/login";
        }

        // Authenticate user
        User authenticatedUser = userService.authenticateUser(email, password);

        if (authenticatedUser != null) {
            // Set user object in session upon successful authentication
            session.setAttribute("user", authenticatedUser);
            return "redirect:/";
        } else {
            // If authentication fails, redirect to login page with error message
            redirectAttributes.addFlashAttribute("error", "Invalid email or password");
            return "redirect:/login";
        }
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/";
    }

}
