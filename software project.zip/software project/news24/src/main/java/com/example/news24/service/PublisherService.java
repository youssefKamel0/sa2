package com.example.news24.service;

import com.example.news24.entity.Publisher;

public interface PublisherService {
    Publisher savePublisher(Publisher publisher);
    Publisher authenticateUser(String email, String password);
    Publisher getUserByEmail(String email);

    public boolean isEmailExists(String email);
}
