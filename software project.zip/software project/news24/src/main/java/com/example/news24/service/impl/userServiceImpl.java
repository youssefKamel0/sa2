package com.example.news24.service.impl;

import com.example.news24.entity.Publisher;
import com.example.news24.entity.User;
import com.example.news24.repo.UserRepo;
import com.example.news24.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class userServiceImpl implements UserService {

    @Autowired
    private UserRepo userrepo;

    public userServiceImpl(UserRepo userrepo) {
        this.userrepo = userrepo;
    }

    @Override
    public User saveUser(User user) {
        // You may want to perform additional validation or logic here before saving
        return userrepo.save(user);
    }

    @Override
    public User authenticateUser(String email, String password) {
        User user = userrepo.findByEmail(email);
        if (user != null && BCrypt.checkpw(password, user.getPassword())) {
            return user;
        }
        return null; // Authentication failed
    }

    @Override
    public User getUserByEmail(String email) {
        return userrepo.findByEmail(email);
    }

    @Override
    public boolean isEmailExists(String email) {
        Optional<User> existingPublisher = Optional.ofNullable(userrepo.findByEmail(email));
        return existingPublisher.isPresent();
    }

}
