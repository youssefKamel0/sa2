package com.example.news24.controller;

import com.example.news24.entity.Article;
import com.example.news24.entity.Publisher;
import com.example.news24.entity.Review;
import com.example.news24.entity.User;
import com.example.news24.service.ArticleService;
import com.example.news24.service.PublisherService;
import com.example.news24.service.ReviewService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.ui.Model;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

@Controller
public class articleController {

    private final PublisherService publisherService;
    private final ArticleService articleService;
    private final ArticleValidator articleValidator;
    private final ReviewService reviewService;

    @Autowired
    public articleController(PublisherService publisherService, ArticleService articleService, ReviewService reviewService, ArticleValidator articleValidator) {
        this.publisherService = publisherService;
        this.articleService = articleService;
        this.articleValidator = articleValidator;
        this.reviewService = reviewService;
    }

    @GetMapping("/add-something")
    public String showAddSomethingPage(HttpSession session, Model model) {

        if (session.getAttribute("publisher") == null) {
            return "redirect:/";
        } else {
            model.addAttribute("article", new Article());
            return "add-something";
        }
    }

    // Define the upload directory path relative to the project directory
    private static final String UPLOAD_DIR = "src/main/resources/static/img";

    @PostMapping("/add-something")
    public String addArticle(@Valid @ModelAttribute("article") Article article, BindingResult result, @RequestParam("imageFile") MultipartFile imageFile, HttpSession session) {

        Publisher publisher = (Publisher) session.getAttribute("publisher");
        if (publisher == null) {
            return "redirect:/login-publisher";
        }

        // Validate the article object
        articleValidator.validate(article, result);

        if (result.hasErrors()) {
            return "add-something";
        }

        try {
            String uploadDir = new File(UPLOAD_DIR).getAbsolutePath();
            Path uploadPath = Paths.get(uploadDir);

            if (!Files.exists(uploadPath)) {
                Files.createDirectories(uploadPath);
            }

            String fileName = System.currentTimeMillis() + "-" + imageFile.getOriginalFilename();
            String filePath = uploadDir + File.separator + fileName;
            File dest = new File(filePath);
            imageFile.transferTo(dest);

            article.setImage(fileName); // Save the file name or URL in the article entity
            article.setPublisher(publisher);

            articleService.saveArticle(article);

            return "redirect:/";
        } catch (IOException e) {
            e.printStackTrace();
            return "redirect:/error";
        }
    }


    @GetMapping("/article-details/{id}")
    public String showArticleDetails(@PathVariable Long id, Model model, HttpSession session) {
        Article article = articleService.findById(id);
        if (article == null) {
            return "redirect:/";
        }

        List<Article> similarArticles = articleService.findLastThreeArticles();
        model.addAttribute("article", article);
        model.addAttribute("similarArticles", similarArticles);

        List<Review> reviews = reviewService.getReviewsByArticleId(id);
        model.addAttribute("reviews", reviews);

        boolean userReviewed = false;
        User user = (User) session.getAttribute("user");
        if (user != null) {
            userReviewed = reviewService.hasUserReviewed(user.getId(), article.getId());
        }
        model.addAttribute("userReviewed", userReviewed);

        return "article-details";
    }

    @PostMapping("/add-review")
    public String addReview(@ModelAttribute("review") @Valid Review review,
                            @RequestParam("articleId") Long articleId,
                            BindingResult result,
                            HttpSession session,
                            Model model) {

        if (result.hasErrors()) {
            model.addAttribute("review", review);
            return "redirect:/article-details/" + articleId; // Redirect back to article details if validation fails
        }

        // Retrieve the logged-in user
        User user = (User) session.getAttribute("user");
        if (user == null) {
            // Handle case where user is not logged in
            return "redirect:/login";
        }

        // Set the user for the review
        review.setUser(user);

        // Retrieve the Article entity based on articleId (Assuming you have an ArticleService)
        Article article = articleService.findById(articleId);
        if (article == null) {
            // Handle case where article is not found
            return "redirect:/"; // Redirect to error page or appropriate handling
        }

        // Set the article for the review
        review.setArticle(article);

        // Save the review
        reviewService.addReview(review);

        // Redirect back to the article details page after successfully adding the review
        return "redirect:/article-details/" + articleId;
    }
}
